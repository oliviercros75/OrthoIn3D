OrthoIn3D
--------

To use (with caution), simply do::

    >>> import OrthoIn3D
    >>> print OrthoIn3D.version()