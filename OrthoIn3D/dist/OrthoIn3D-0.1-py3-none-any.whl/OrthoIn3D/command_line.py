import OrthoIn3D

def main():
    OrthoIn3D.show_version()